/*
 * $Id: shuffle_int.h 1048 2006-07-06 20:07:44Z cegrant $
 * 
 * $Log$
 * Revision 1.1  2005/07/29 19:10:58  nadya
 * Initial revision
 *
 */

#ifndef SHUFFLE_INT_H
#define SHUFFLE_INT_H

extern int *shuffle_int(
  int lo,                       /* lowest value */
  int hi                        /* highest value */
);

#endif

