
#ifndef MOTIF_IN_FLAGS_H
#define MOTIF_IN_FLAGS_H

#define OPEN_MFILE 1
#define CALC_AMBIGS 2
#define SCANNED_SITES 4
#define SKIP_POST_PROCESSING 8

#endif
